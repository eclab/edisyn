Did you erase your RAM patches (0...199) in you Matrix 1000?  
Here are the originals for you.
