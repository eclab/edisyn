This is my first attempt to convert publically available M-Audio Venom
patches into standard sysex files.  The patches were originally in 
proprietary Vyzex .sqb, .sqs, and .sgl formats.  The patches were
largely converted by loading them and either monitoring the resulting
sysex message output or selecting an entire bank and asking Vyzex
to dump it to MIDI.

These patches came from the collection available for download at
http://www.venom-synth.com/  One collection (the "Jimdo" collection)
was not converted because it appeared to me to contain garbage.

I have no doubt that there were many errors in the conversion process
but this is the best I could do with the resources I had: Vyzex
Venom is an awful, terrible program filled to the brim with bugs and
design mistakes.

I cannot speak as to the quality, authorship, provenance, or 
function of these patches; I just converted them.

Sean Luke
sean@cs.gmu.edu
